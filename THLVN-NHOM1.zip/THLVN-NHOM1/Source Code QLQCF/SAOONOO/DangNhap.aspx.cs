﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;

namespace SAOONOO
{
    public partial class DangNhap : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                DAO.LoginDAO DAO = new SAOONOO.DAO.LoginDAO();

                string us = txtUser.Text;
                string pass = txtPass.Text;
                if (DAO.CheckChucVu(us, pass))
                    {
                        Session[us] = txtUser;
                        Response.Redirect("~/QLTKNV.aspx");
                    } 
                
                else
                    if (DAO.CheckLogin(us, pass))
                    {
                        Session[us] = txtUser;
                        Response.Redirect("QLNV.aspx");

                    }
                          
                    else
                    {
                        lblThongBao.Text = "Đăng nhập không thành công ! Vui lòng thử lại!";
                    }
            }
        }
        
    }
}