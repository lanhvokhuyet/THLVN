﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SAOONOO.DTO
{
    public class nv
    {
        string manv;

        public string Manv
        {
            get { return manv; }
            set { manv = value; }
        }
        string hoten;

        public string Hoten
        {
            get { return hoten; }
            set { hoten = value; }
        }
        string ngaysinh;

        public string Ngaysinh
        {
            get { return ngaysinh; }
            set { ngaysinh = value; }
        }
        

       bool gioitinh;

        public bool Gioitinh
        {
            get { return gioitinh; }
            set { gioitinh = value; }
        }
        string sdt;

        public string Sdt
        {
            get { return sdt; }
            set { sdt = value; }
        }
        string diachi;

        public string Diachi
        {
            get { return diachi; }
            set { diachi = value; }
        }
        string vitrilamviec;

        public string Vitrilamviec
        {
            get { return vitrilamviec; }
            set { vitrilamviec = value; }
        }
    }
}