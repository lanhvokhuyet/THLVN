﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SAOONOO.DTO
{
    public class ban
    {
        string maBan;

        public string MaBan
        {
            get { return maBan; }
            set { maBan = value; }
        }
        string tenBan;

        public string TenBan
        {
            get { return tenBan; }
            set { tenBan = value; }
        }
    }
}