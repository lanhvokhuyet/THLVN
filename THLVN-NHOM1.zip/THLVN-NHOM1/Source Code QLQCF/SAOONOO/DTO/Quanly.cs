﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SAOONOO.DTO
{
    public class Quanly
    {
        string userName;

        public string UserName
        {
            get { return userName; }
            set { userName = value; }
        }
        string passWord;

        public string PassWord
        {
            get { return passWord; }
            set { passWord = value; }
        }
        string hoten;

        public string Hoten
        {
            get { return hoten; }
            set { hoten = value; }
        }
        string chucvu;

        public string Chucvu
        {
            get { return chucvu; }
            set { chucvu = value; }
        }
    }
}